package com.maya.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class ChatLine(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var pendingListen: ((String) -> Unit)? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { MayaScreen(
            getKey = { getSharedPreferences("maya", MODE_PRIVATE).getString("gemini_key", "") ?: "" },
            saveKey = { getSharedPreferences("maya", MODE_PRIVATE).edit().putString("gemini_key", it).apply() },
            onSpeak = { speak(it) },
            onListen = { onResult -> startListening(onResult) }
        ) }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("hi", "IN")
            tts?.setSpeechRate(1.0f)
        }
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maya_reply") }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 811) {
            val callback = pendingListen
            pendingListen = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && callback != null) {
                startListening(callback)
            } else {
                callback?.invoke("Microphone permission nahi mili, Boss. Settings se permission allow karo.")
            }
        }
    }
    private fun startListening(onResult: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { onResult("Is phone par speech recognition available nahi hai."); return }
        val launch = {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { recognizer.destroy(); onResult("Awaaz samajh nahi aayi. Dobara try karo.") }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    recognizer.destroy(); onResult(words)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Maya ko bolo")
            }
            recognizer.startListening(intent)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launch()
        else { pendingListen = onResult; requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 811) }
    }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MayaScreen(getKey: () -> String, saveKey: (String) -> Unit, onSpeak: (String) -> Unit, onListen: ((String) -> Unit) -> Unit) {
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf(getKey()) }
    var showSettings by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready • Text aur voice mode") }
    val chat = remember { mutableStateListOf(ChatLine("Namaste Boss. Main Maya hoon. Batao, kya karna hai?", false)) }
    val bg = Color(0xFF0A0E18)
    val panel = Color(0xFF151D2D)
    val cyan = Color(0xFF67E8F9)

    MaterialTheme(colorScheme = darkColorScheme(
        primary = cyan, background = bg, surface = panel, onSurface = Color(0xFFEAF2FF),
        onBackground = Color(0xFFEAF2FF)
    )) {
        Scaffold(containerColor = bg, topBar = {
            TopAppBar(
                title = { Column { Text("MAYA", letterSpacing = 3.sp); Text("Hinglish Phone Assistant", fontSize = 12.sp, color = Color.LightGray) } },
                actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = bg, titleContentColor = Color.White)
            )
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Card(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 12.dp), colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(22.dp)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(54.dp).background(Color(0xFF123746), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Mic, null, tint = cyan, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Maya is ready", color = Color.White, fontSize = 17.sp)
                            Text(status, color = cyan, fontSize = 12.sp)
                        }
                        IconButton(onClick = { onSpeak("Haan Boss, main sun rahi hoon.") }) { Icon(Icons.Default.VolumeUp, "Test voice", tint = cyan) }
                    }
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(chat) { line ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                            Surface(color = if (line.fromUser) Color(0xFF164E63) else panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                                Text(line.text, Modifier.padding(horizontal = 14.dp, vertical = 11.dp), color = Color.White, fontSize = 15.sp)
                            }
                        }
                    }
                    if (busy) item { Text("Maya soch rahi hai…", color = cyan, fontSize = 13.sp) }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.weight(1f), color = panel, shape = RoundedCornerShape(26.dp)) {
                        BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp), singleLine = false, decorationBox = { inner -> if (input.isEmpty()) Text("Boss, Maya ko bolo…", color = Color.Gray); inner() })
                    }
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = { status = "Listening…"; onListen { result -> if (result.isNotBlank()) input = result; status = "Ready" } }) {
                        Icon(Icons.Default.Mic, "Voice input", tint = cyan, modifier = Modifier.size(28.dp))
                    }
                    IconButton(enabled = input.isNotBlank() && !busy, onClick = {
                        val prompt = input.trim()
                        if (prompt.isNotEmpty()) {
                            chat.add(ChatLine(prompt, true)); input = ""; busy = true
                            scope.launch {
                                val response = withContext(Dispatchers.IO) { askGemini(apiKey, prompt) }
                                chat.add(ChatLine(response, false)); busy = false; status = "Ready"
                                onSpeak(response)
                            }
                        }
                    }) { Icon(Icons.Default.Send, "Send", tint = cyan) }
                }
                Text("API key device par locally save hoti hai. Phone actions abhi connected nahi hain.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp))
            }
        }
        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Maya settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Gemini API key")
                    OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), placeholder = { Text("Apni key yahan paste karo") })
                    Text("Key sirf is phone ke app preferences mein save hoti hai. Kisi ko share mat karo.", fontSize = 12.sp, color = Color.Gray)
                }
            },
            confirmButton = { TextButton(onClick = { saveKey(apiKey.trim()); showSettings = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
        )
    }
}

private fun askGemini(key: String, message: String): String {
    if (key.isBlank()) return "Boss, pehle Settings mein apni Gemini API key save karo. Main voice input aur chat UI test kar sakti hoon, lekin AI reply ke liye key chahiye."
    return try {
        val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + URLEncoder.encode(key, "UTF-8"))
        val conn = (endpoint.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        }
        val body = JSONObject().put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
            "Tum Maya ho, ek helpful Hinglish phone assistant. Roman Hinglish mein 1-3 chhote sentences do. User ko Boss bulao. Sach bolo; phone action kiya hone ka jhootha daava mat karo. Messages send ya files delete karne se pehle confirmation maango. Is app mein abhi direct phone automation integrated nahi hai."
        )))).put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", message)))))
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) return "Boss, Gemini request fail hui (HTTP $code). API key, model access aur quota check karo."
        val root = JSONObject(text)
        root.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
            ?.takeIf { it.isNotBlank() } ?: "Boss, is baar clear reply nahi mila. Dobara try karo."
    } catch (_: Exception) {
        "Boss, internet ya Gemini connection mein problem aa rahi hai. Connection check karke dobara try karo."
    }
}
